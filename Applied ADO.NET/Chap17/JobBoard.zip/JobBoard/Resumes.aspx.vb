Imports System.Data.SqlClient

Public Class Resumes
  Inherits System.Web.UI.Page
  Protected WithEvents ResumeList As System.Web.UI.WebControls.DataList

    Public connectionString As String = _
    "Data Source=localhost;Initial Catalog=dnJobs; " & _
    "user id=mahesh;password=mahesh;"
  Public sql As String = Nothing
  Public conn As SqlConnection = Nothing
  Public StartIndex As Integer = 0
  Shared PageSize As Integer = 1
  Shared CurrentIndex As Integer = 0
    Shared TotalRecords As Integer = 0
    Public ds As DataSet = Nothing

  Protected WithEvents LastBtn As System.Web.UI.WebControls.Button
  Protected WithEvents NextBtn As System.Web.UI.WebControls.Button
  Protected WithEvents PrevBtn As System.Web.UI.WebControls.Button
  Protected WithEvents FirstBtn As System.Web.UI.WebControls.Button


#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles MyBase.Load
    FillDataGrid()
    FillPartialData(0)
  End Sub

  Private Sub FillDataGrid()
    ds = New DataSet()
    conn = New SqlConnection()
    conn.ConnectionString = connectionString
    ' Open connection
    If conn.State <> ConnectionState.Open Then
      conn.Open()
    End If
    sql = "SELECT * FROM Resumes"
    Dim adapter As SqlDataAdapter = _
      New SqlDataAdapter(sql, conn)
    adapter.Fill(ds, "Resumes")
    TotalRecords = ds.Tables(0).Rows.Count
    ' Close connection
    If conn.State <> ConnectionState.Closed Then
      conn.Close()
    End If
  End Sub

  Private Sub FillPartialData(ByVal start As Integer)
    Dim tempDs As DataSet = ds.Clone()
    Dim i As Integer = 0
    Dim range As Integer = start + PageSize
    For i = start To range - 1
      Dim row As DataRow = tempDs.Tables(0).NewRow()
      row(0) = ds.Tables(0).Rows(i)(0)
      row(1) = ds.Tables(0).Rows(i)(1)
      row(2) = ds.Tables(0).Rows(i)(2)
      row(3) = ds.Tables(0).Rows(i)(3)
      row(4) = ds.Tables(0).Rows(i)(4)
      row(5) = ds.Tables(0).Rows(i)(5)
      row(6) = ds.Tables(0).Rows(i)(6)
      row(7) = ds.Tables(0).Rows(i)(7)
      row(8) = ds.Tables(0).Rows(i)(8)

      tempDs.Tables(0).Rows.Add(row)
    Next
    tempDs.Tables(0).AcceptChanges()
    ResumeList.DataSource = tempDs
    ResumeList.DataBind()
  End Sub

  Private Sub FirstBtn_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles FirstBtn.Click
    CurrentIndex = 0
    FillPartialData(CurrentIndex)
  End Sub

  Private Sub PrevBtn_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles PrevBtn.Click
    CurrentIndex -= PageSize
    If (CurrentIndex < 0) Then
      CurrentIndex = 0
    End If
    FillPartialData(CurrentIndex)
  End Sub

  Private Sub NextBtn_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles NextBtn.Click
    CurrentIndex += PageSize
    If (CurrentIndex >= TotalRecords) Then
      CurrentIndex = TotalRecords - PageSize
    End If
    FillPartialData(CurrentIndex)
  End Sub

  Private Sub LastBtn_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles LastBtn.Click
    CurrentIndex = TotalRecords - PageSize
    FillPartialData(CurrentIndex)
  End Sub

    Private Sub HomeBtn_Click(ByVal sender As System.Object, _
 ByVal e As System.EventArgs)
        Me.Response.Redirect("Login.aspx")
    End Sub
End Class
