Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class PostJob
  Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

    Public connectionString As String = _
    "Data Source=localhost;Initial Catalog=dnJobs;user id=mahesh;password=mahesh;"
  Public sql As String = Nothing
  Public conn As SqlConnection = Nothing
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents Label2 As System.Web.UI.WebControls.Label
  Protected WithEvents Label3 As System.Web.UI.WebControls.Label
  Protected WithEvents Label4 As System.Web.UI.WebControls.Label
  Protected WithEvents SaveBtn As System.Web.UI.WebControls.Button
  Protected WithEvents ResetBtn As System.Web.UI.WebControls.Button
  Protected WithEvents CompanyTxtBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents ReqTxtBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents DesTxtBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents DetailsTxtBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label5 As System.Web.UI.WebControls.Label
  Protected WithEvents ContactsTxtBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label6 As System.Web.UI.WebControls.Label
  Protected WithEvents Label7 As System.Web.UI.WebControls.Label
  Protected WithEvents Label8 As System.Web.UI.WebControls.Label
  Protected WithEvents Label9 As System.Web.UI.WebControls.Label
  Protected WithEvents DoneBtn As System.Web.UI.WebControls.Button
  Protected WithEvents StatusBar As System.Web.UI.WebControls.Label
  Public cmd As SqlCommand = Nothing

  Private Sub Page_Load(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles MyBase.Load
    'Put user code to initialize the page here
  End Sub

  Private Sub SaveBtn_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles SaveBtn.Click
    conn = New SqlConnection()
    conn.ConnectionString = connectionString
    ' Construct an INSERT query with parameters
    sql = "INSERT INTO Job(Company, Contacts, Description, " & _
    "Requirements, Details, PostingDate) " & _
    "VALUES (@comp, @cont, @req, @des, @det, @post)"
    cmd = New SqlCommand(sql, conn)
    cmd.CommandType = CommandType.Text
    cmd.CommandText = sql
    ' Add parameters with values from text boxes
    cmd.Parameters.Add("@comp", CompanyTxtBox.Text)
    cmd.Parameters.Add("@cont", ContactsTxtBox.Text)
    cmd.Parameters.Add("@req", ReqTxtBox.Text)
    cmd.Parameters.Add("@des", DesTxtBox.Text)
    cmd.Parameters.Add("@det", DetailsTxtBox.Text)
    cmd.Parameters.Add("@post", _
    SqlDbType.DateTime).Value = DateTime.Today.ToString()
    ' Open connection
    If conn.State <> ConnectionState.Open Then
      conn.Open()
    End If
    ' Execute the query
    cmd.ExecuteNonQuery()
    ' Close connection
    If conn.State <> ConnectionState.Closed Then
      conn.Close()
    End If
    ClearFields()
    StatusBar.Text = "Thank you for Job Posting"
  End Sub

  Private Sub ClearFields()
    CompanyTxtBox.Text = ""
    ContactsTxtBox.Text = ""
    ReqTxtBox.Text = ""
    DesTxtBox.Text = ""
    DetailsTxtBox.Text = ""
  End Sub

  Private Sub ResetBtn_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles ResetBtn.Click
    ClearFields()
  End Sub

  Private Sub DoneBtn_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles DoneBtn.Click
    Response.Redirect("Login.aspx")
  End Sub
End Class
