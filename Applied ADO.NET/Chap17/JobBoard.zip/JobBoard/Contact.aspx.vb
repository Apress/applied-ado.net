Imports System.Web.Mail

Public Class Contact
  Inherits System.Web.UI.Page
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents Label2 As System.Web.UI.WebControls.Label
  Protected WithEvents Label3 As System.Web.UI.WebControls.Label
  Protected WithEvents Label4 As System.Web.UI.WebControls.Label
  Protected WithEvents SubTextBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents SendMailBtn As System.Web.UI.WebControls.Button
  Protected WithEvents FromTextBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents ToTextBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents MsgTextBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents StatusBar As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles MyBase.Load
    'Put user code to initialize the page here
  End Sub

  Private Sub SendMailBtn_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles SendMailBtn.Click

    Dim msg As MailMessage = New MailMessage()
    msg.To = ToTextBox.Text
        msg.From = FromTextBox.Text
    msg.Subject = SubTextBox.Text
    msg.Body = MsgTextBox.Text
        SmtpMail.SmtpServer = "mail5.fiberspeed.net"
    SmtpMail.Send(msg)
    StatusBar.Text = "Message recieved. We will contact you soon. "

  End Sub
End Class
