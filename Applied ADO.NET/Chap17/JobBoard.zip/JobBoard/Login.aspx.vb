Imports System.Data.SqlClient

Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

    Public connectionString As String = _
    "Data Source=localhost;Initial Catalog=dnJobs;user id=mahesh;password=mahesh;"
    Public sql As String = Nothing
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents IdTextBox As System.Web.UI.WebControls.TextBox
    Protected WithEvents PassTextBox As System.Web.UI.WebControls.TextBox
    Protected WithEvents LoginBtn As System.Web.UI.WebControls.Button
    Protected WithEvents NewUserLink As System.Web.UI.WebControls.HyperLink
    Protected WithEvents PostJobBtn As System.Web.UI.WebControls.Button
    Protected WithEvents PostResumeBtn As System.Web.UI.WebControls.Button
    Protected WithEvents ViewJobsBtn As System.Web.UI.WebControls.Button
    Protected WithEvents ViewResumesBtn As System.Web.UI.WebControls.Button
    Protected WithEvents StatusBar As System.Web.UI.WebControls.Label
    Public conn As SqlConnection = Nothing

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Application("ConnectionString") = connectionString
        Application("Title") = "Job Board"


    End Sub

    Private Sub PostResumeBtn_Click(ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles PostResumeBtn.Click
        Me.Response.Redirect("PostResume.aspx")
    End Sub

    Private Sub ViewJobsBtn_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles ViewJobsBtn.Click
        Me.Response.Redirect("DisplayData.aspx")
    End Sub

    Private Sub PostJobBtn_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles PostJobBtn.Click
        Me.Response.Redirect("PostJob.aspx")
    End Sub

    Private Sub ViewResumesBtn_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles ViewResumesBtn.Click
        Me.Response.Redirect("Resumes.aspx")
    End Sub

    Private Sub SendMsgBtn_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs)
        Response.Redirect("Contact.aspx")
    End Sub

    Private Sub LoginBtn_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles LoginBtn.Click

        ' Create and open a connection
        conn = New SqlConnection(connectionString)
        If (conn.State <> ConnectionState.Open) Then
            conn.Open()
        End If
        ' Construct a SQL string
        sql = "SELECT * FROM Users WHERE UserID='" + _
           IdTextBox.Text + _
           "' AND Password = '" + PassTextBox.Text + "'"
        '  and fill it 
        Dim reader As SqlDataReader
        Dim cmd As SqlCommand = New SqlCommand(sql)
        cmd.Connection = conn
        reader = cmd.ExecuteReader(CommandBehavior.SingleRow)
        If (reader.Read()) Then
            PostJobBtn.Visible = True
            PostResumeBtn.Visible = True
            ViewJobsBtn.Visible = True
            ViewResumesBtn.Visible = True
            StatusBar.Text = "Logged In"
            Label1.Visible = False
            Label2.Visible = False
            IdTextBox.Visible = False
            PassTextBox.Visible = False
            NewUserLink.Visible = False
            LoginBtn.Visible = False
        Else
            StatusBar.Text = _
                "Enter a valid User ID and Password!"
        End If
        ' Close the connection
        If (conn.State = ConnectionState.Open) Then
            conn.Close()
        End If
    End Sub



End Class
