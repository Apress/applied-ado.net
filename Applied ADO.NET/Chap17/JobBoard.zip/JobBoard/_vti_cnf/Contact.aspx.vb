vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Oct 2002 00:11:00 -0000
vti_extenderversion:SR|4.0.2.5322
