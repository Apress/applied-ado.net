vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|31 Oct 2002 20:11:22 -0000
vti_extenderversion:SR|4.0.2.5322
