Imports System.Data.SqlClient

Public Class Register
  Inherits System.Web.UI.Page
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents Label2 As System.Web.UI.WebControls.Label
  Protected WithEvents Label3 As System.Web.UI.WebControls.Label
  Protected WithEvents IdTextBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents PassTextBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents EmailTextBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents Label4 As System.Web.UI.WebControls.Label
  Protected WithEvents RegisterBtn As System.Web.UI.WebControls.Button
  Protected WithEvents BackBtn As System.Web.UI.WebControls.Button


    Public connectionString As String = _
  "Data Source=localhost;Initial Catalog=dnJobs;user id=mahesh;password=mahesh;"
  Public sql As String = Nothing
  Public cmd As SqlCommand = Nothing
  Protected WithEvents StatusBar As System.Web.UI.WebControls.Label
    Public conn As SqlConnection = Nothing

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles MyBase.Load
    'Put user code to initialize the page here
  End Sub

  Private Sub RegisterBtn_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles RegisterBtn.Click
    If IsValid Then
      ' Create a connection
      conn = New SqlConnection()
      conn.ConnectionString = connectionString
      'Open connection
      If conn.State <> ConnectionState.Open Then
        conn.Open()
      End If
      ' Construct an INSERT query with parameters
      sql = "INSERT INTO Users(UserID, Password, Email) " & _
      "VALUES (@id, @pass, @email)"
      cmd = New SqlCommand(sql, conn)
      cmd.CommandType = CommandType.Text
      ' Add parameters with values from text boxes
      cmd.Parameters.Add("@id", IdTextBox.Text)
      cmd.Parameters.Add("@pass", PassTextBox.Text)
      cmd.Parameters.Add("@email", EmailTextBox.Text)

      ' Execute the query
      Try
        cmd.ExecuteNonQuery()
      Catch exp As Exception
        StatusBar.Text = exp.Message.ToString()
      End Try
      ' Close connection
      If conn.State <> ConnectionState.Closed Then
        conn.Close()
      End If
      IdTextBox.Text = ""
      EmailTextBox.Text = ""
      StatusBar.Text = "Thank you registring with us."
    End If

  End Sub

  Private Sub BackBtn_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles BackBtn.Click
    Response.Redirect("Login.aspx")
  End Sub
End Class
