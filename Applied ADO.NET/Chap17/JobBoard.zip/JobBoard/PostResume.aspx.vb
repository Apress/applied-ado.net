Imports System.Data.SqlClient

Public Class PostResume
  Inherits System.Web.UI.Page
  Protected WithEvents Label1 As System.Web.UI.WebControls.Label
  Protected WithEvents Label2 As System.Web.UI.WebControls.Label
  Protected WithEvents Label3 As System.Web.UI.WebControls.Label
  Protected WithEvents Label4 As System.Web.UI.WebControls.Label
  Protected WithEvents Label5 As System.Web.UI.WebControls.Label
  Protected WithEvents PostResumeBtn As System.Web.UI.WebControls.Button
  Protected WithEvents ResetFieldsBtn As System.Web.UI.WebControls.Button

    Public connectionString As String = _
   "Data Source=localhost;Initial Catalog=dnJobs;user id=mahesh;password=mahesh;"
  Public sql As String = Nothing
  Public cmd As SqlCommand = Nothing
  Public conn As SqlConnection = Nothing

  Protected WithEvents NameTxtBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents EmailTxtBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents TitleTxtBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents AddTxtBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents ResumeTxtBox As System.Web.UI.WebControls.TextBox
  Protected WithEvents Required As System.Web.UI.WebControls.Label
  Protected WithEvents Label6 As System.Web.UI.WebControls.Label
  Protected WithEvents Label7 As System.Web.UI.WebControls.Label
  Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
  Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents EduList As System.Web.UI.WebControls.DropDownList
    Protected WithEvents StatusList As System.Web.UI.WebControls.DropDownList
  Protected WithEvents DoneBtn As System.Web.UI.WebControls.Button
  Protected WithEvents StatusBar As System.Web.UI.WebControls.Label
  Protected WithEvents RadioButtonList1 As System.Web.UI.WebControls.RadioButtonList



#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles MyBase.Load
    'Put user code to initialize the page here
    FillListBoxes()
  End Sub

  Private Sub FillListBoxes()
    ' This method adds selection data to list boxes
        EduList.Items.Add("Master's Degree")
        EduList.Items.Add("Bachelor's Degree")
    EduList.Items.Add("Some College")
    EduList.Items.Add("2 Yrs Diploma")
    StatusList.Items.Add("US Citizen")
    StatusList.Items.Add("Green Card or Authorized to work")
    StatusList.Items.Add("H1 Visa")
    StatusList.Items.Add("Need Sponsorship")
  End Sub

  Private Sub PostResumeBtn_Click(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles PostResumeBtn.Click
    conn = New SqlConnection()
    conn.ConnectionString = connectionString
    ' Construct an INSERT query with parameters
        sql = "INSERT INTO Resumes(Name, Email, Address, Resume, " & _
        "Title, PostingDate, Education, Status, Relocate) " & _
        "VALUES (@nam, @mail, @add, @res, @tit, @post, @edu, @stat, @rel)"
    cmd = New SqlCommand(sql, conn)
    cmd.CommandType = CommandType.Text
    ' Add parameters with values from text boxes
    cmd.Parameters.Add("@nam", NameTxtBox.Text)
    cmd.Parameters.Add("@mail", EmailTxtBox.Text)
    cmd.Parameters.Add("@add", AddTxtBox.Text)
    cmd.Parameters.Add("@res", ResumeTxtBox.Text)
    cmd.Parameters.Add("@tit", TitleTxtBox.Text)
        cmd.Parameters.Add("@post", _
        SqlDbType.DateTime).Value = DateTime.Today.ToString()
        cmd.Parameters.Add("@edu", EduList.SelectedItem.Text.ToString)
        cmd.Parameters.Add("@stat", StatusList.SelectedItem.Text.ToString)


    If (RadioButtonList1.SelectedIndex = 1) Then
      cmd.Parameters.Add("@rel", "Yes")
    Else
      cmd.Parameters.Add("@rel", "No")
    End If

    ' Open connection
    If conn.State <> ConnectionState.Open Then
      conn.Open()
    End If
    ' Execute the query

    Try
      cmd.ExecuteNonQuery()
    Catch exp As Exception
      StatusBar.Text = exp.Message.ToString()
    End Try

    ' Close connection
    If conn.State <> ConnectionState.Closed Then
      conn.Close()
    End If
    ClearFields()
    StatusBar.Text = "Thank you for posting your resume."
  End Sub

  Private Sub DoneBtn_Click(ByVal sender As System.Object, _
ByVal e As System.EventArgs) Handles DoneBtn.Click
    Response.Redirect("Login.aspx")
  End Sub

  Private Sub ClearFields()
    NameTxtBox.Text = ""
    EmailTxtBox.Text = ""
    AddTxtBox.Text = ""
    ResumeTxtBox.Text = ""
    TitleTxtBox.Text = ""
  End Sub

  Private Sub ResetFieldsBtn_Click _
  (ByVal sender As System.Object, ByVal e As System.EventArgs) _
  Handles ResetFieldsBtn.Click
    ClearFields()
  End Sub
End Class
